'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'weebly';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f5cc';
var svgPathData = 'M425.1 65.8c-39.9 0-73.3 25.7-83.7 64.3-18.2-58.1-65.5-64.3-85-64.3-19.8 0-66.8 6.3-85.3 64.3-10.4-38.6-43.4-64.3-83.7-64.3-49 0-87.5 33.9-87.5 77.2 0 29 4.2 33.3 77.2 233.5 22.4 60.6 67.8 69.4 92.7 69.4 39.2 0 70-19.5 85.9-54 15.9 34.8 46.7 54.3 85.9 54.3 25 0 70.4-9.1 92.7-69.7 76.6-208.6 77.5-205.6 77.5-227.2 .6-48.3-36-83.5-86.9-83.5zm26.3 114.8L385.9 357.1c-7.9 21.5-21.2 37.2-46.2 37.2-23.4 0-37.4-12.4-44-33.9l-39.3-117.4-1 0-39.3 117.4c-7 21.5-20.9 33.6-44 33.6-25 0-38.3-15.7-46.2-37.2L60.9 181.6c-5.4-14.8-7.9-23.9-7.9-34.5 0-16.3 15.8-29.4 38.3-29.4 18.7 0 32 11.8 36.1 29.1l44 139.8 1 0 44.7-136.8c6-19.7 16.5-32.1 39-32.1s32.9 12.1 39 32.1l44.7 136.8 1 0 44-139.8c4.1-17.2 17.4-29.1 36.1-29.1 22.2 0 38.3 13.3 38.3 35.7-.3 7.9-4.1 16-7.6 27.2z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faWeebly = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;