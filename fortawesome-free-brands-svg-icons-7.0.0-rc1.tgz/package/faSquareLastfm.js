'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'square-lastfm';
var width = 448;
var height = 512;
var aliases = ["lastfm-square"];
var unicode = 'f203';
var svgPathData = 'M448 96c0-35.3-28.7-64-64-64L64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-320zM210.7 280.8c-1.8-5.5-3.4-10.8-5-15.9-12.9-41.9-21-68.4-58-68.4-22.4 0-45.1 16.1-45.1 61.2 0 35.2 18 57.2 43.3 57.2 28.6 0 47.6-21.3 47.6-21.3l11.7 31.9s-19.8 19.4-61.2 19.4c-51.3 0-79.9-30.1-79.9-85.8 0-57.9 28.6-92 82.5-92 67.9 0 79.3 35.3 96.4 88.4 1.4 4.4 2.9 8.9 4.4 13.5 8.8 26.8 24.2 46.2 61.2 46.2 24.9 0 38.1-5.5 38.1-19.1 0-17.5-16.9-21.2-40-26.4-3.2-.7-6.5-1.4-9.9-2.2-30.4-7.3-42.5-23.1-42.5-48 0-40 32.3-52.4 65.2-52.4 37.4 0 60.1 13.6 63 46.6l-36.7 4.4c-1.5-15.8-11-22.4-28.6-22.4-16.1 0-26 7.3-26 19.8 0 11 4.8 17.6 20.9 21.3 2.2 .5 4.5 1 6.7 1.4 31.1 6.5 65.1 13.7 65.1 56.1 .1 36.7-30.7 50.6-76.1 50.6-63.4 0-85.4-28.6-97.1-64.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faSquareLastfm = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;