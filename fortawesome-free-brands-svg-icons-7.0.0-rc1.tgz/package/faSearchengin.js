'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'searchengin';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f3eb';
var svgPathData = 'M214.6 130.3l-67.2 28.2 0-115.3-54.7 190.3 54.7-24.2 0 130.3 67.2-209.3zM131.4 33.6l-1.3 4.7-15.2 52.9C74.6 106.7 46 145.8 46 191.5 46 243.8 80.3 287.4 129.4 297l0 53.6C51.5 340.1-6 272.4-6 191.6-6 111.1 53.8 44.4 131.4 33.6zM442.8 480.8c-11.2 11.2-23.1 12.3-28.6 10.5-5.4-1.8-27.1-19.9-60.4-44.4-33.3-24.6-33.6-35.7-43-56.7-9.4-20.9-30.4-42.6-57.5-52.4l-9.7-14.7c-24.7 16.9-53 26.9-81.3 28.7l2.1-6.6 15.9-49.5c46.5-11.9 80.9-54 80.9-104.2 0-54.5-38.4-102.1-96-107.1l0-52.1c83.2 5.1 148.8 74.5 148.8 159.3 0 33.6-11.2 64.7-29 90.4l14.6 9.6c9.8 27.1 31.5 48 52.4 57.4s32.2 9.7 56.8 43c24.6 33.2 42.7 54.9 44.5 60.3s.7 17.3-10.5 28.5zm-9.9-17.9c0-4.4-3.6-8-8-8s-8 3.6-8 8 3.6 8 8 8 8-3.6 8-8z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faSearchengin = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;