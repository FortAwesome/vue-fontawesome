'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'nutritionix';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f3d6';
var svgPathData = 'M112 8.1S245.4-.1 233 112.5c0 0 19.1-74.9 103-40.6 0 0-17.7 74-88 56 0 0 14.6-54.6 66.1-56.6 0 0-39.9-10.3-82.1 48.8 0 0-19.8-94.5-93.6-99.7 0 0 75.2 19.4 77.6 107.5 0 .1-106.4 7-104-119.8zM424 323.7c0 48.5-9.7 95.3-32 132.3-42.2 30.9-105 48-168 48-62.9 0-125.8-17.1-168-48-22.3-37-32-83.8-32-132.3 0-48.4 17.7-94.7 40-131.7 42.2-30.9 97.1-48.6 160-48.6 63 0 117.8 17.6 160 48.6 22.3 37 40 83.3 40 131.7zM144 428a28 28 0 1 0 -56 0 28 28 0 1 0 56 0zm0-66.2a28 28 0 1 0 -56 0 28 28 0 1 0 56 0zm0-66.2a28 28 0 1 0 -56 0 28 28 0 1 0 56 0zM216 428a28 28 0 1 0 -56 0 28 28 0 1 0 56 0zm0-66.2a28 28 0 1 0 -56 0 28 28 0 1 0 56 0zm0-66.2a28 28 0 1 0 -56 0 28 28 0 1 0 56 0zM288 428a28 28 0 1 0 -56 0 28 28 0 1 0 56 0zm0-66.2a28 28 0 1 0 -56 0 28 28 0 1 0 56 0zm0-66.2a28 28 0 1 0 -56 0 28 28 0 1 0 56 0zM360 428a28 28 0 1 0 -56 0 28 28 0 1 0 56 0zm0-66.2a28 28 0 1 0 -56 0 28 28 0 1 0 56 0zm0-66.2a28 28 0 1 0 -56 0 28 28 0 1 0 56 0zM384 256c-4.8-22.3-7.4-36.9-16-56-38.8-19.9-90.5-32-144-32S118.8 180.1 80 200c-8.8 19.5-11.2 33.9-16 56 42.2-7.9 98.7-14.8 160-14.8s117.8 6.9 160 14.8z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faNutritionix = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;