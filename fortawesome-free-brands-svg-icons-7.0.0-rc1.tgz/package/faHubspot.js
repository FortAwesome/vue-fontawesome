'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'hubspot';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f3b2';
var svgPathData = 'M235.8 211.6c-25.1 23.7-40.8 57.3-40.8 94.6 0 29.3 9.7 56.3 26 78L171.5 434c-4.4-1.6-9.1-2.5-14-2.5-10.8 0-20.9 4.2-28.5 11.8s-11.8 17.8-11.8 28.6 4.2 20.9 11.8 28.5 17.8 11.6 28.5 11.6c10.8 0 20.9-3.9 28.6-11.6 7.6-7.6 11.8-17.8 11.8-28.5 0-4.2-.6-8.2-1.9-12.1l50-50.2c22 16.9 49.4 26.9 79.3 26.9 71.9 0 130-58.3 130-130.2 0-65.2-47.7-119.2-110.2-128.7l0-61.6c17.5-7.4 28.2-23.8 28.2-42.9 0-26.1-20.9-47.9-47-47.9S279.6 47 279.6 73.1c0 19.1 10.7 35.5 28.2 42.9l0 61.2c-15.2 2.1-29.6 6.7-42.7 13.6-27.6-20.9-117.5-85.7-168.9-124.8 1.2-4.4 2-9 2-13.8 0-28.8-23.5-52.2-52.4-52.2-28.8 0-52.2 23.4-52.2 52.2 0 28.9 23.4 52.3 52.2 52.3 9.8 0 18.9-2.9 26.8-7.6L235.8 211.6zm89.5 25.6a69 69 0 1 1 0 138 69 69 0 1 1 0-138z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faHubspot = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;