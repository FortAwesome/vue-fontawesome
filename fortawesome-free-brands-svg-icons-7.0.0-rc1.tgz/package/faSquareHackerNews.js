'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'square-hacker-news';
var width = 448;
var height = 512;
var aliases = ["hacker-news-square"];
var unicode = 'f3af';
var svgPathData = 'M448 96c0-35.3-28.7-64-64-64L64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-320zM21 229.2s.1-.1 .1-.2 .1-.2 .2-.2c0 .1 0 .3-.1 .4l-.2 0zM239.2 384l-31.4 0 0-102.7-79.8-153.3 37.3 0c41.5 77.7 48.1 95.8 54.1 112 1.6 4.3 3.1 8.5 5.2 13.6 3.2-7 5.1-11.9 7.1-17.3 5.9-15.3 12.8-33.2 53.5-108.3l34.8 0-80.8 155.1 0 100.9z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faSquareHackerNews = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;