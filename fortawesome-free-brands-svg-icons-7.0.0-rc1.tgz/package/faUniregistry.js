'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'uniregistry';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'f404';
var svgPathData = 'M192 480c39.5 0 76.2-11.8 106.8-32.2l-213.5 0C115.8 468.2 152.5 480 192 480zM102.9 286.9l0-12.4-102.9 0 0 12.4c0 2.5 0 5 .1 7.4l103.1 0c-.2-2.4-.3-4.9-.3-7.4zm20.5 57l-114.9 0c2.6 8.5 5.8 16.8 9.6 24.8l138.3 0c-12.9-5.7-24.1-14.2-33-24.8zm-17.7-34.7l-104.4 0c.9 7.6 2.2 15 3.9 22.3l109.7 0c-4-6.9-7.2-14.4-9.2-22.3zm-2.8-69.3l-102.9 0 0 17.3 102.9 0 0-17.3zm0-173.2l-102.9 0 0 4.9 102.9 0 0-4.9zm0-34.7l-102.9 0 0 2.5 102.9 0 0-2.5zm0 69.3l-102.9 0 0 7.4 102.9 0 0-7.4zm0 104l-102.9 0 0 14.8 102.9 0 0-14.8zm0-69.3l-102.9 0 0 9.9 102.9 0 0-9.9zm0 34.6l-102.9 0 0 12.4 102.9 0 0-12.4zM269.1 331.5l109.7 0c1.8-7.3 3.1-14.7 3.9-22.3l-104.4 0c-2.1 7.9-5.2 15.4-9.2 22.3zm12-185.7l102.9 0 0-9.8-102.9 0 0 9.8zm0 37.2l102.9 0 0-12.4-102.9 0 0 12.4zm0-74.3l102.9 0 0-7.4-102.9 0 0 7.4zm0-76.7l0 2.5 102.9 0 0-2.5-102.9 0zM78.1 442.9l227.7 0c11.8-8.7 22.7-18.6 32.2-29.7l-293.1 0c9.6 11 21.4 21 33.2 29.7zm203-371.3l102.9 0 0-4.9-102.9 0 0 4.9zm0 148.5l102.9 0 0-14.8-102.9 0 0 14.8zM38.8 405.7l305.3 0c6.7-8.5 12.6-17.6 17.8-27.2L23 378.5c5.2 9.6 9.2 18.7 15.8 27.2zm188.8-37.1l139.4 0c3.7-8 5.8-16.2 8.5-24.8l-115 0c-8.8 10.7-20.1 19.2-32.9 24.8zm53.5-81.7c0 2.5-.1 5-.4 7.4l103.1 0c.1-2.5 .2-4.9 .2-7.4l0-12.4-102.9 0 0 12.4zm0-29.7l102.9 0 0-17.3-102.9 0 0 17.3z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faUniregistry = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;