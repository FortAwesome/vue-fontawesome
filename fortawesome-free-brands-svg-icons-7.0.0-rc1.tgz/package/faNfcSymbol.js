'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'nfc-symbol';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e531';
var svgPathData = 'M360.9 32.4c7.7-1.3 15.7 .5 21.2 5 84.1 58.7 129.9 136.3 129.9 217.7 0 83.1-45.8 160.8-129.9 219.5-4.8 4-11.7 5.9-18.6 5.3-7-.6-13.5-3.6-18.4-8.5L161.7 288.7c-5.6-5.5-8.7-13-9.6-20.9 0-7.8 4-15.3 9.5-20.9 5.6-5.5 13.1-8.7 20.9-8.7 7.9 0 15.4 3.1 20.9 8.6L368.5 411.2c54.6-44.7 84.3-99.2 84.3-156.1 0-61.6-36.9-122.2-103.9-169.3-6.4-4.5-10.8-11.4-12.1-19.1-1.4-7.7 .4-15.7 5-22.1 4.5-6.4 11.4-10.8 19.1-12.1zm-206 447.2c-7.7 1.3-15.6-.5-22.1-5-83.1-58.7-129-136.4-129-219.5 0-81.4 45.8-159 129-217.7 5.7-4 12.6-5.9 19.6-5.3 6.9 .6 13.4 3.6 18.3 8.5L354.1 223.3c5.6 5.5 8.7 13 8.7 20.9 .1 6.9-3 15.3-8.6 20.9-5.5 5.5-13 8.7-20.9 8.7-7.8 0-16.2-3.1-20.9-8.6L147.3 100.7c-54.6 45.2-84.3 99.2-84.3 154.4 0 63.4 36.9 124 103.1 171.1 7.3 4.6 11.6 11.4 13 19.2 1.3 7.7-.5 15.7-5 22.1s-11.4 10.7-19.2 12.1z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faNfcSymbol = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;