'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'fedex';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'f797';
var svgPathData = 'M586 284.5l53.3-59.9-62.4 0-21.7 24.8-22.5-24.8-118.7 0 0-16 56.1 0 0-48.1-151.2 0 0 75.5-.5 0c-9.6-11-21.5-14.8-35.4-14.8-28.4 0-49.8 19.4-57.3 44.9-18-59.4-97.4-57.6-121.9-14l0-24.2-54.8 0 0-26.2 60 0 0-41.1-109 0 0 184.4 49 0 0-77.5 48.9 0c-1.5 5.7-2.3 11.8-2.3 18.2 0 73.1 102.6 91.4 130.2 23.7l-42 0c-14.7 20.9-45.8 8.9-45.8-14.6l85.5 0c3.7 30.5 27.4 56.9 60.1 56.9 14.1 0 27-6.9 34.9-18.6l.5 0 0 11.9 212.2 0 22.1-25 22.3 25 64.4 0-54-60.5zM139.3 267.9c6.1-26.3 41.7-25.6 46.5 0l-46.5 0zm153.4 48.9c-34.6 0-34-62.8 0-62.8 32.6 0 34.5 62.8 0 62.8zm167.8 19.1l-94.4 0 0-166.5 95 0 0 30.2-56.1 0 0 33.9 55.5 0 0 28.1-56.1 0 0 44.7 56.1 0 0 29.6zm-45.9-39.8l0-24.4 56.1 0 0-44 50.7 57-50.7 57 0-45.6-56.1 0zm138.6 10.3l-26.1 29.5-38.1 0 45.6-51.2-45.6-51.2 39.7 0 26.6 29.3 25.6-29.3 38.5 0-45.4 51 46 51.4-40.5 0-26.3-29.5z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faFedex = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;