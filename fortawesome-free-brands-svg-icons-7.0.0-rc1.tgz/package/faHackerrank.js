'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'hackerrank';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f5f7';
var svgPathData = 'M477.9 128C463.4 103 285.5 0 256.5 0s-206.9 102.8-221.3 128-14.5 230.8 0 256 192.4 128 221.3 128 206.8-102.9 221.3-128 14.5-231 0-256zM316.5 414.2c-4 0-40.9-35.8-38-38.7 .9-.9 6.3-1.5 17.5-1.8 0-26.2 .6-68.6 .9-86.3 0-2-.4-3.4-.4-5.8l-79.9 0c0 7.1-.5 36.2 1.4 72.9 .2 4.5-1.6 6-5.7 5.9-10.1 0-20.3-.1-30.4-.1-4.1 0-5.9-1.5-5.7-6.1 .9-33.4 3-84-.2-212.7l0-3.2c-9.7-.4-16.4-1-17.3-1.8-2.9-2.9 34.5-38.7 38.5-38.7s41.2 35.8 38.3 38.7c-.9 .9-7.9 1.5-16.8 1.8l0 3.2c-2.4 25.8-2 79.6-2.6 105.4l80.3 0c0-4.6 .4-34.7-1.2-83.6-.1-3.4 1-5.2 4.2-5.2 11.1-.1 22.2-.1 33.2-.1 3.5 0 4.6 1.7 4.5 5.4-3.7 191.3-.7 177.9-.7 210.3 8.9 .4 16.8 1 17.7 1.8 2.9 2.9-33.6 38.7-37.6 38.7l0 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faHackerrank = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;