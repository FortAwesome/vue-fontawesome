'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'pushed';
var width = 448;
var height = 512;
var aliases = [];
var unicode = 'f3e1';
var svgPathData = 'M415.1 111.9l-98.5-9 14-33.4c10.4-23.5-10.8-40.4-28.7-37L30.6 76.9c-15.1 2.7-26 18.3-21.4 36.6L114.3 461.8c6.5 21.3 36.7 24.2 47.7 7L197.3 388 432.5 156.7c16.4-16.8 4.3-42.9-17.4-44.8zM305.7 53.6c5.1-.7 7.5 2.5 5.2 7.4l-16.8 39.9-177.4-16.3 189-31zM30.8 107.9c-3.1-5.1 1-10 6.1-9.1l248.7 22.7-96.9 230.7-157.9-244.3zM144.1 456.4c-2.6 4-7.9 3.1-9.4-1.2L51.6 179.7 179.3 377.3c-7 15-35.2 79.1-35.2 79.1zM416.9 141.9l-198.7 195.4 89.7-213.7 106.4 9.7c4 1.1 5.7 5.3 2.6 8.6z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faPushed = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;