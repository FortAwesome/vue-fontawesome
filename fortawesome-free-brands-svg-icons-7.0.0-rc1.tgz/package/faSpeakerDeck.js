'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'speaker-deck';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f83c';
var svgPathData = 'M213.9 296L100 296c-26.5 0-52-10.5-70.7-29.3S0 222.5 0 196 10.5 144 29.3 125.3 73.5 96 100 96l132.8 0c10.6 0 20.8 4.2 28.3 11.7s11.7 17.7 11.7 28.3-4.2 20.8-11.7 28.3-17.7 11.7-28.3 11.7L98 176c-26.5 0-26.4 40 0 40l113.8 0c26.5 0 52 10.5 70.7 29.3s29.3 44.2 29.3 70.7-10.5 52-29.3 70.7-44.2 29.3-70.7 29.3L40 416c-10.6 0-20.8-4.2-28.3-11.7S0 386.6 0 376 4.2 355.2 11.7 347.7 29.4 336 40 336l173.9 0c26.5 0 26.5-40 0-40zM298 416c13.5-9.2 25-21 33.8-34.7s14.7-29.2 17.3-45.3l64.6 0c2.6 0 5.2-.6 7.6-1.6s4.6-2.5 6.4-4.4 3.3-4.1 4.2-6.5 1.5-5 1.4-7.6l0-120c0-2.6-.5-5.2-1.4-7.6s-2.4-4.6-4.2-6.5-4-3.3-6.4-4.4-5-1.6-7.6-1.6l-117.2 0c9.7-11.1 15-25.3 15-40s-5.3-28.9-15-40l136.9 0c43.4 0 78.6 35.8 78.6 80l0 160c0 44.2-35.2 80-78.6 80L298 416z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faSpeakerDeck = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;