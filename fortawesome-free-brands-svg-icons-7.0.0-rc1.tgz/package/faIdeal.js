'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fab';
var iconName = 'ideal';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'e013';
var svgPathData = 'M93.8 165.5a49.1 49.1 0 1 0 0 98.1 49.1 49.1 0 1 0 0-98.1zM54.3 425.8l78.9 0 0-140.5-78.9 0 0 140.5zM205.8 214.2c0-20-10-22.5-18.7-22.5l-14 0 0 45.8 14 0c9.7 0 18.7-2.8 18.7-23.3zm201.7 46l0-91.3 22.8 0 0 68.6 33.7 0C454.6 113.1 356.8 86.2 267.8 86.2l-94.8 0 0 82.8 14 0c25.6 0 41.5 17.4 41.5 45.3 0 28.8-15.5 46-41.5 46l-14 0 0 165.6 94.8 0c144.6 0 194.9-67.2 196.7-165.6l-57.1 0zm-109.8 0l-56.2 0 0-91.2 54.4 0 0 22.7-31.7 0 0 10.6 30 0 0 22.7-30 0 0 12.5 33.5 0 0 22.7zm74.7 0l-5.2-17.7-29.7 0-5.2 17.7-23.7 0 27.5-91.3 32.3 0 27.5 91.3-23.7 0zM267.8 32L.1 32 .1 480 267.8 480c161.8 0 251-79.7 251-224.5 0-83.5-32.6-223.5-251-223.5zm0 426.9l-246.6 0 0-405.9 246.6 0c142.1 0 229.9 64.6 229.9 202.4 0 134.1-81 203.4-229.9 203.4zm83.9-264.9l-7.5 25.8 16.4 0-7.5-25.8-1.4 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faIdeal = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;