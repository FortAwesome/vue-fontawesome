'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'bottle-droplet';
var width = 320;
var height = 512;
var aliases = [];
var unicode = 'e4c4';
var svgPathData = 'M80 0c0-17.7 14.3-32 32-32l96 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l0 103.3c64.9 20.4 112 81 112 152.7l0 192c0 35.3-28.7 64-64 64L64 544c-35.3 0-64-28.7-64-64L0 288c0-71.6 47.1-132.3 112-152.7L112 32C94.3 32 80 17.7 80 0zm80 416c35.3 0 64-32.4 64-64 0-21.2-28.9-64.5-47.9-90.6-8.1-11.1-24.2-11.1-32.3 0-19 26.1-47.9 69.4-47.9 90.6 0 31.6 28.7 64 64 64z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBottleDroplet = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;