'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'cart-flatbed-suitcase';
var width = 576;
var height = 512;
var aliases = ["luggage-cart"];
var unicode = 'f59d';
var svgPathData = 'M0 32C0 14.3 14.3 0 32 0L48 0c44.2 0 80 35.8 80 80l0 288c0 8.8 7.2 16 16 16l400 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-34.7 0c1.8 5 2.7 10.4 2.7 16 0 26.5-21.5 48-48 48s-48-21.5-48-48c0-5.6 1-11 2.7-16l-197.5 0c1.8 5 2.7 10.4 2.7 16 0 26.5-21.5 48-48 48s-48-21.5-48-48c0-6 1.1-11.7 3.1-17-38.1-6.2-67.1-39.2-67.1-79L64 80c0-8.8-7.2-16-16-16L32 64C14.3 64 0 49.7 0 32zM176 144c0-26.5 21.5-48 48-48l32 0 0-24c0-30.9 25.1-56 56-56l64 0c30.9 0 56 25.1 56 56l0 24 32 0c26.5 0 48 21.5 48 48l0 144c0 26.5-21.5 48-48 48l-240 0c-26.5 0-48-21.5-48-48l0-144zM384 96l0-24c0-4.4-3.6-8-8-8l-64 0c-4.4 0-8 3.6-8 8l0 24 80 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCartFlatbedSuitcase = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;