'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'bridge-lock';
var width = 576;
var height = 512;
var aliases = [];
var unicode = 'e4cc';
var svgPathData = 'M0 64C0 46.3 14.3 32 32 32l448 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-8 0 0 32.2c13.8 .6 27.2 2.8 40 6.4l0 50.7c-14.8-6-31-9.3-48-9.3-70.7 0-128 57.3-128 128l0 24.4c-.4 .3-.7 .6-1.1 1-17.3-25-46.2-41.3-78.9-41.3-53 0-96 43-96 96l0 64c0 17.7-14.3 32-32 32l-32 0c-17.7 0-32-14.3-32-32l0-94c0-38.8-26.4-72.6-64-82l0-112 40 0 0-64-8 0C14.3 96 0 81.7 0 64zm424 68.6l0-36.6-80 0 0 64 18.8 0c18.2-12.8 38.9-22.2 61.2-27.4zM216 96l0 64 80 0 0-64-80 0zm-48 0l-80 0 0 64 80 0 0-64zM496 304.1c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 47.9 64 0 0-47.9zM352 400c0-20.9 13.4-38.7 32-45.3l0-50.6c0-44.2 35.8-80 80-80s80 35.8 80 80l0 50.6c18.6 6.6 32 24.4 32 45.3l0 96c0 26.5-21.5 48-48 48l-128 0c-26.5 0-48-21.5-48-48l0-96z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBridgeLock = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;