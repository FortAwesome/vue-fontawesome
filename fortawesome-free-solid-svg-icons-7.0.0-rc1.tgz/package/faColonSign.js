'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'colon-sign';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'e140';
var svgPathData = 'M213.8 8.7c12.9 3.2 20.7 16.2 17.5 29.1l-4.6 18.5c15.4 .8 30.4 3.4 44.7 7.5l9.4-37.6C283.9 13.3 297 5.5 309.8 8.7S330.5 25 327.3 37.8L316 82.8c13.5 7.8 26 17.1 37.2 27.8 12.9 12.1 13.4 32.4 1.3 45.2s-32.4 13.4-45.2 1.3c-3.1-2.9-6.4-5.8-9.8-8.4L239.2 390c26.9-4.6 51.1-17.1 70.1-35.1 12.9-12.1 33.1-11.5 45.2 1.3s11.5 33.1-1.3 45.2c-34.3 32.3-80 52.8-130.5 54.4l-7.5 29.9c-3.2 12.9-16.2 20.7-29.1 17.5s-20.7-16.2-17.5-29.1l5.6-22.5c-15-3.2-29.4-8-42.9-14.4l-12.1 48.5c-3.2 12.9-16.2 20.7-29.1 17.5S69.5 487 72.7 474.2l16-63.9C44.3 373.6 16 318.1 16 256 16 159.2 84.8 78.4 176.3 60l8.4-33.8C187.9 13.3 201 5.5 213.8 8.7zM158 132.9c-46.1 21.8-78 68.7-78 123.1 0 30.5 10 58.6 26.9 81.3L158 132.9zM147.4 373.4c13 7.6 27.3 13.1 42.5 16.1l65.9-263.6c-12.6-3.8-25.9-5.9-39.8-5.9-1.8 0-3.5 0-5.3 .1L147.4 373.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faColonSign = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;