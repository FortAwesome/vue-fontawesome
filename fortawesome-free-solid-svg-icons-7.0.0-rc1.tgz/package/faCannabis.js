'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'cannabis';
var width = 512;
var height = 512;
var aliases = [];
var unicode = 'f55f';
var svgPathData = 'M256 0c5.3 0 10.3 2.7 13.3 7.1 15.8 23.5 36.7 63.7 49.2 109 7.3 26.4 11.8 55.3 10.3 84 11.6-8.9 23.7-16.7 35.9-23.7 41-23.3 84.4-36.9 112.2-42.5 5.2-1 10.7 .6 14.4 4.4s5.4 9.2 4.4 14.5c-5.6 27.7-19.3 70.9-42.7 111.7-9.1 15.9-19.9 31.7-32.5 46.3 27.9 6.6 52.5 17.2 67.3 25.4 5.1 2.8 8.2 8.2 8.2 14s-3.2 11.2-8.2 14c-15.2 8.4-40.9 19.5-69.8 26.1-20.2 4.6-42.9 7.2-65.2 4.6l8.3 33.2c1.5 6.1-.6 12.5-5.5 16.4s-11.6 4.6-17.2 1.8L280 417.2 280 488c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-70.8-58.5 29.1c-5.6 2.8-12.3 2.1-17.2-1.8s-7-10.3-5.5-16.4l8.3-33.2c-22.2 2.6-45 0-65.2-4.6-28.9-6.6-54.5-17.6-69.8-26.1-5.1-2.8-8.2-8.2-8.2-14s3.2-11.2 8.2-14l6.2-3.3c15-7.6 36.8-16.4 61.1-22.2-12.5-14.5-23.3-30.4-32.4-46.2-23.4-40.8-37.1-84-42.7-111.7-1.1-5.2 .6-10.7 4.4-14.5s9.2-5.4 14.4-4.4c27.9 5.5 71.2 19.2 112.2 42.5 12.2 6.9 24.3 14.8 35.8 23.7-1.4-28.7 3.1-57.6 10.3-84 12.5-45.3 33.4-85.5 49.2-109l1.2-1.6C246.9 2 251.3 0 256 0z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCannabis = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;